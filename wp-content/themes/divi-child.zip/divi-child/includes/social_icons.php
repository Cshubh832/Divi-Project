<ul class="et-social-icons">
<li class="et-social-icon et-social-facebook">
		<a href="<?php echo esc_attr(get_option('facebook')); ?>" class="icon" target="_blank">
			
		</a>
	</li>
	
<li class="et-social-icon et-social-tumblr">
        <a href="<?php echo esc_attr(get_option('tumb')); ?>" class="icon" target="_blank">
            
        </a>
    </li>
	
	<li class="et-social-icon et-social-instagram">
        <a href="<?php echo esc_attr(get_option('insta')); ?>" class="icon" target="_blank">
            
        </a>
    </li>
	
	<li class="et-social-icon aln-info-email">
		<a href="mailto:<?php echo get_option('email'); ?>" class="icon" target="_blank">
			
		</a>
	</li>
    
	
</ul>